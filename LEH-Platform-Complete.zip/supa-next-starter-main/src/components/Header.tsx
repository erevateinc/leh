import LEHLogo from './LEHLogo'

export default function Header() {
  return (
    <div className="flex flex-col items-center gap-16">
      <div className="flex items-center justify-center">
        <LEHLogo />
      </div>
      <h1 className="sr-only">LEH - Layer Express Hub</h1>
      <p className="mx-auto max-w-xl text-center text-3xl !leading-tight lg:text-4xl">
        Transform your knowledge into{' '}
        <span className="font-bold text-blue-600">AI personas</span>{' '}
        and monetize your expertise
      </p>
      <p className="mx-auto max-w-2xl text-center text-lg text-muted-foreground">
        Create, share, and sell AI versions of yourself. Let others learn from your knowledge 
        while you earn from your expertise.
      </p>
      <div className="my-8 w-full bg-gradient-to-r from-transparent via-foreground/10 to-transparent p-[1px]" />
    </div>
  )
}
