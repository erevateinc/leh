import Image from 'next/image'

export default function LEHLogo() {
  return (
    <div className="flex items-center gap-2">
      <Image
        src="/leh-logo.png"
        alt="LEH Logo"
        width={48}
        height={48}
        className="rounded-full"
      />
      <span className="text-2xl font-bold text-foreground">LEH</span>
    </div>
  )
}

