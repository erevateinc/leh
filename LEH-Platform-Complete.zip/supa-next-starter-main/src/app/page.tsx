import AuthButton from '@/components/AuthButton'
import Header from '@/components/Header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { cookies } from 'next/headers'
import { createServerClient } from '@/utils/supabase'
import ThemeToggle from '@/components/ThemeToggle'
import Link from 'next/link'
import { Brain, Users, DollarSign, Zap } from 'lucide-react'

export default async function Index() {
  const cookieStore = cookies()

  const canInitSupabaseClient = () => {
    try {
      createServerClient(cookieStore)
      return true
    } catch (e) {
      return false
    }
  }

  const isSupabaseConnected = canInitSupabaseClient()

  return (
    <div className="flex w-full flex-1 flex-col items-center gap-20">
      <nav className="flex h-16 w-full justify-center border-b border-b-foreground/10">
        <div className="flex w-full max-w-4xl items-center justify-between p-3 text-sm">
          <div className="flex items-center gap-4">
            <Link href="/" className="font-bold text-lg">LEH</Link>
            <Link href="/marketplace" className="hover:underline">Marketplace</Link>
            <Link href="/create" className="hover:underline">Create</Link>
          </div>
          {isSupabaseConnected && <AuthButton />}
        </div>
      </nav>

      <div className="flex max-w-6xl flex-1 flex-col gap-20 px-3">
        <Header />
        
        <main className="flex flex-1 flex-col gap-12">
          <div className="text-center">
            <Link href="/create">
              <Button size="lg" className="text-lg px-8 py-6">
                <Brain className="mr-2 h-5 w-5" />
                Create Your AI Persona
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-blue-600" />
                  Create
                </CardTitle>
                <CardDescription>
                  Transform your knowledge into an AI persona
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Upload your expertise, documents, and knowledge. Our AI will learn from your content and create a persona that thinks like you.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-green-600" />
                  Share
                </CardTitle>
                <CardDescription>
                  Let others interact with your AI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Publish your AI persona to the marketplace. Others can chat with it, learn from it, and even fork it to create their own versions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-yellow-600" />
                  Earn
                </CardTitle>
                <CardDescription>
                  Monetize your expertise
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Set rental or purchase prices for your AI persona. Earn money every time someone uses your knowledge and expertise.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">How it works</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
              <div className="flex flex-col items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">1</div>
                <p>Upload your knowledge</p>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">2</div>
                <p>AI learns from your content</p>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">3</div>
                <p>Set your pricing</p>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">4</div>
                <p>Start earning</p>
              </div>
            </div>
          </div>
        </main>
      </div>

      <footer className="w-full justify-center border-t border-t-foreground/10 p-8 text-center text-xs">
        <p className="mb-6">
          Powered by LEH - Layer Express Hub
        </p>
        <ThemeToggle />
      </footer>
    </div>
  )
}
