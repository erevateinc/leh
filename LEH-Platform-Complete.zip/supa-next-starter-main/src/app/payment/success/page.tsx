'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, Brain, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'

interface PaymentSession {
  status: string
  customerEmail: string
  metadata: {
    personaId: string
    priceType: string
  }
}

export default function PaymentSuccessPage() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get('session_id')
  const [session, setSession] = useState<PaymentSession | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (sessionId) {
      fetchPaymentSession()
    }
  }, [sessionId])

  const fetchPaymentSession = async () => {
    try {
      const response = await fetch(`/api/payment?session_id=${sessionId}`)
      if (response.ok) {
        const data = await response.json()
        setSession(data)
      }
    } catch (error) {
      console.error('Error fetching payment session:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto max-w-2xl p-6 flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Verifying your payment...</p>
        </div>
      </div>
    )
  }

  if (!session || session.status !== 'paid') {
    return (
      <div className="container mx-auto max-w-2xl p-6 flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Payment Verification Failed</CardTitle>
            <CardDescription>
              We couldn't verify your payment. Please contact support if you believe this is an error.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/marketplace">
              <Button>Return to Marketplace</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto max-w-2xl p-6 flex items-center justify-center min-h-screen">
      <Card className="w-full">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-600">Payment Successful!</CardTitle>
          <CardDescription>
            Thank you for your purchase. You now have access to your AI persona.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-800 mb-2">Purchase Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Email:</span>
                <span className="font-medium">{session.customerEmail}</span>
              </div>
              <div className="flex justify-between">
                <span>Access Type:</span>
                <span className="font-medium">
                  {session.metadata.priceType === 'rental' ? 'Monthly Subscription' : 'Lifetime Access'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Persona ID:</span>
                <span className="font-medium">{session.metadata.personaId}</span>
              </div>
            </div>
          </div>

          <div className="text-center space-y-4">
            <p className="text-muted-foreground">
              You can now start chatting with your AI persona and access all its features.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href={`/persona/${session.metadata.personaId}`} className="flex-1">
                <Button className="w-full">
                  <Brain className="h-4 w-4 mr-2" />
                  Start Chatting
                </Button>
              </Link>
              <Link href="/marketplace" className="flex-1">
                <Button variant="outline" className="w-full">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  Browse More Personas
                </Button>
              </Link>
            </div>
          </div>

          <div className="border-t pt-4">
            <h4 className="font-semibold mb-2">What's Next?</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Access your purchased persona anytime from your dashboard</li>
              <li>• {session.metadata.priceType === 'rental' ? 'Your subscription will auto-renew monthly' : 'You have lifetime access to this persona'}</li>
              <li>• You can fork this persona to create your own enhanced version</li>
              <li>• Rate and review the persona to help other users</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

