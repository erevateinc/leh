'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Upload, Brain, Zap } from 'lucide-react'
import type { AIEngine } from '@/utils/ai-engines'

export default function CreatePersonaPage() {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    engine: '' as AIEngine,
    knowledge: '',
    price_rental: '',
    price_purchase: '',
  })

  const [isCreating, setIsCreating] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsCreating(true)
    
    try {
      // TODO: Implement persona creation logic
      console.log('Creating persona:', formData)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      alert('AI Persona created successfully!')
    } catch (error) {
      console.error('Error creating persona:', error)
      alert('Failed to create persona. Please try again.')
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <div className="container mx-auto max-w-4xl p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Create AI Persona</h1>
        <p className="text-muted-foreground mt-2">
          Transform your knowledge into an AI persona that others can interact with and learn from.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Basic Information
            </CardTitle>
            <CardDescription>
              Define the core identity of your AI persona
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Persona Name</Label>
              <Input
                id="name"
                placeholder="e.g., Marketing Expert Sarah"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe what your AI persona specializes in and how it can help others..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="engine">AI Engine</Label>
              <Select
                value={formData.engine}
                onValueChange={(value: AIEngine) => setFormData({ ...formData, engine: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose an AI engine" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="deepseek">
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      DeepSeek (Fast & Efficient)
                    </div>
                  </SelectItem>
                  <SelectItem value="gemini">
                    <div className="flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Gemini (Versatile)
                    </div>
                  </SelectItem>
                  <SelectItem value="claude">
                    <div className="flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Claude (Advanced Reasoning)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Knowledge Base
            </CardTitle>
            <CardDescription>
              Provide the knowledge and expertise your AI persona should have
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="knowledge">Knowledge Content</Label>
              <Textarea
                id="knowledge"
                placeholder="Paste your knowledge, expertise, documents, or any content you want your AI to learn from..."
                value={formData.knowledge}
                onChange={(e) => setFormData({ ...formData, knowledge: e.target.value })}
                required
                rows={8}
                className="font-mono text-sm"
              />
              <p className="text-sm text-muted-foreground mt-2">
                Tip: Include examples, case studies, methodologies, or any specific knowledge you want your AI to reference.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pricing</CardTitle>
            <CardDescription>
              Set how much you want to charge for access to your AI persona
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price_rental">Monthly Rental Price ($)</Label>
                <Input
                  id="price_rental"
                  type="number"
                  placeholder="9.99"
                  value={formData.price_rental}
                  onChange={(e) => setFormData({ ...formData, price_rental: e.target.value })}
                  min="0"
                  step="0.01"
                />
              </div>
              
              <div>
                <Label htmlFor="price_purchase">One-time Purchase Price ($)</Label>
                <Input
                  id="price_purchase"
                  type="number"
                  placeholder="49.99"
                  value={formData.price_purchase}
                  onChange={(e) => setFormData({ ...formData, price_purchase: e.target.value })}
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={isCreating} size="lg">
            {isCreating ? 'Creating...' : 'Create AI Persona'}
          </Button>
        </div>
      </form>
    </div>
  )
}

