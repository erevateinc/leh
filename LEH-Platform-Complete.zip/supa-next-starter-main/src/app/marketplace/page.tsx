'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Search, Brain, DollarSign, Users, GitFork, MessageCircle } from 'lucide-react'
import Link from 'next/link'
import { createPaymentSession, redirectToCheckout } from '@/utils/payment'

interface AIPersona {
  id: string
  name: string
  description: string
  engine: 'deepseek' | 'gemini' | 'claude'
  creator: string
  price_rental: number
  price_purchase: number
  users_count: number
  rating: number
}

// Mock data for demonstration
const mockPersonas: AIPersona[] = [
  {
    id: '1',
    name: 'Marketing Expert Sarah',
    description: 'Expert in digital marketing strategies, SEO, and social media campaigns. Helps businesses grow their online presence.',
    engine: 'claude',
    creator: 'Sarah Johnson',
    price_rental: 9.99,
    price_purchase: 49.99,
    users_count: 156,
    rating: 4.8
  },
  {
    id: '2',
    name: 'Python Programming Mentor',
    description: 'Experienced Python developer with expertise in web development, data science, and automation.',
    engine: 'deepseek',
    creator: 'Alex Chen',
    price_rental: 14.99,
    price_purchase: 79.99,
    users_count: 89,
    rating: 4.9
  },
  {
    id: '3',
    name: 'Investment Advisor Pro',
    description: 'Professional investment advisor with 15+ years of experience in portfolio management and financial planning.',
    engine: 'gemini',
    creator: 'Michael Roberts',
    price_rental: 19.99,
    price_purchase: 149.99,
    users_count: 234,
    rating: 4.7
  }
]

export default function MarketplacePage() {
  const [personas, setPersonas] = useState<AIPersona[]>(mockPersonas)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredPersonas, setFilteredPersonas] = useState<AIPersona[]>(mockPersonas)
  const [loadingPayment, setLoadingPayment] = useState<string | null>(null)

  useEffect(() => {
    const filtered = personas.filter(persona =>
      persona.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      persona.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      persona.creator.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setFilteredPersonas(filtered)
  }, [searchTerm, personas])

  const handlePurchase = async (persona: AIPersona, priceType: 'rental' | 'purchase') => {
    setLoadingPayment(`${persona.id}-${priceType}`)
    
    try {
      const amount = priceType === 'rental' ? persona.price_rental : persona.price_purchase
      const { url } = await createPaymentSession({
        personaId: persona.id,
        personaName: persona.name,
        priceType,
        amount,
      })
      
      redirectToCheckout(url)
    } catch (error) {
      console.error('Payment error:', error)
      alert('Failed to initiate payment. Please try again.')
    } finally {
      setLoadingPayment(null)
    }
  }

  const getEngineColor = (engine: string) => {
    switch (engine) {
      case 'deepseek': return 'bg-blue-100 text-blue-800'
      case 'gemini': return 'bg-green-100 text-green-800'
      case 'claude': return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getEngineIcon = (engine: string) => {
    switch (engine) {
      case 'deepseek': return '⚡'
      case 'gemini': return '🧠'
      case 'claude': return '🎯'
      default: return '🤖'
    }
  }

  return (
    <div className="container mx-auto max-w-6xl p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AI Persona Marketplace</h1>
        <p className="text-muted-foreground">
          Discover and interact with AI personas created by experts around the world.
        </p>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search personas, creators, or expertise..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPersonas.map((persona) => (
          <Card key={persona.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{persona.name}</CardTitle>
                  <CardDescription className="text-sm text-muted-foreground">
                    by {persona.creator}
                  </CardDescription>
                </div>
                <Badge className={getEngineColor(persona.engine)}>
                  {getEngineIcon(persona.engine)} {persona.engine}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4 line-clamp-3">{persona.description}</p>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {persona.users_count}
                </div>
                <div className="flex items-center gap-1">
                  <span>⭐</span>
                  {persona.rating}
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Monthly:</span>
                  <span className="font-semibold">${persona.price_rental}/mo</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">One-time:</span>
                  <span className="font-semibold">${persona.price_purchase}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Link href={`/persona/${persona.id}`} className="flex-1">
                  <Button variant="outline" size="sm" className="w-full">
                    <MessageCircle className="h-4 w-4 mr-1" />
                    Chat
                  </Button>
                </Link>
                <Link href={`/fork/${persona.id}`}>
                  <Button variant="outline" size="sm">
                    <GitFork className="h-4 w-4 mr-1" />
                    Fork
                  </Button>
                </Link>
                <div className="relative">
                  <Button 
                    size="sm" 
                    className="bg-blue-600 hover:bg-blue-700"
                    onClick={() => handlePurchase(persona, 'purchase')}
                    disabled={loadingPayment === `${persona.id}-purchase`}
                  >
                    <DollarSign className="h-4 w-4 mr-1" />
                    {loadingPayment === `${persona.id}-purchase` ? 'Processing...' : 'Buy'}
                  </Button>
                  {/* Rental option - could be added as dropdown */}
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="ml-1"
                    onClick={() => handlePurchase(persona, 'rental')}
                    disabled={loadingPayment === `${persona.id}-rental`}
                  >
                    {loadingPayment === `${persona.id}-rental` ? 'Processing...' : 'Rent'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPersonas.length === 0 && (
        <div className="text-center py-12">
          <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No personas found</h3>
          <p className="text-muted-foreground">
            Try adjusting your search terms or browse all available personas.
          </p>
        </div>
      )}
    </div>
  )
}

