'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { GitFork, Brain, Zap, ArrowRight, Plus } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { AIEngine } from '@/utils/ai-engines'

interface AIPersona {
  id: string
  name: string
  description: string
  engine: AIEngine
  creator: string
  knowledge: string
  price_rental: number
  price_purchase: number
}

// Mock original persona data
const mockOriginalPersona: AIPersona = {
  id: '1',
  name: 'Marketing Expert Sarah',
  description: 'Expert in digital marketing strategies, SEO, and social media campaigns. Helps businesses grow their online presence.',
  engine: 'deepseek',
  creator: 'Sarah Johnson',
  knowledge: 'I am a digital marketing expert with over 10 years of experience in SEO, social media marketing, content strategy, and paid advertising. I help businesses develop comprehensive marketing strategies that drive growth and engagement.',
  price_rental: 9.99,
  price_purchase: 49.99
}

export default function ForkPersonaPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [originalPersona] = useState<AIPersona>(mockOriginalPersona)
  const [formData, setFormData] = useState({
    name: `${mockOriginalPersona.name} (Forked)`,
    description: mockOriginalPersona.description,
    engine: mockOriginalPersona.engine,
    knowledge: mockOriginalPersona.knowledge,
    additional_knowledge: '',
    price_rental: '',
    price_purchase: '',
  })
  const [isCreating, setIsCreating] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsCreating(true)
    
    try {
      // TODO: Implement fork creation logic
      console.log('Creating forked persona:', formData)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      alert('Forked AI Persona created successfully!')
      router.push('/marketplace')
    } catch (error) {
      console.error('Error creating forked persona:', error)
      alert('Failed to create forked persona. Please try again.')
    } finally {
      setIsCreating(false)
    }
  }

  const getEngineColor = (engine: string) => {
    switch (engine) {
      case 'deepseek': return 'bg-blue-100 text-blue-800'
      case 'gemini': return 'bg-green-100 text-green-800'
      case 'claude': return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getEngineIcon = (engine: string) => {
    switch (engine) {
      case 'deepseek': return '⚡'
      case 'gemini': return '🧠'
      case 'claude': return '🎯'
      default: return '🤖'
    }
  }

  return (
    <div className="container mx-auto max-w-6xl p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <GitFork className="h-8 w-8" />
          Fork AI Persona
        </h1>
        <p className="text-muted-foreground mt-2">
          Create your own version based on an existing AI persona. You can modify and enhance it with your own knowledge.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Original Persona */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Original Persona
            </CardTitle>
            <CardDescription>
              This is the persona you're forking from
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-lg">{originalPersona.name}</h3>
                <p className="text-sm text-muted-foreground">by {originalPersona.creator}</p>
              </div>
              <Badge className={getEngineColor(originalPersona.engine)}>
                {getEngineIcon(originalPersona.engine)} {originalPersona.engine}
              </Badge>
            </div>
            
            <p className="text-sm">{originalPersona.description}</p>
            
            <div>
              <Label className="text-sm font-medium">Original Knowledge Base:</Label>
              <div className="mt-1 p-3 bg-muted rounded-md text-sm max-h-32 overflow-y-auto">
                {originalPersona.knowledge}
              </div>
            </div>

            <div className="flex justify-between text-sm">
              <span>Monthly: ${originalPersona.price_rental}</span>
              <span>One-time: ${originalPersona.price_purchase}</span>
            </div>
          </CardContent>
        </Card>

        {/* Fork Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Your Forked Version
            </CardTitle>
            <CardDescription>
              Customize and enhance the original persona
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">New Persona Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Updated Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="engine">AI Engine</Label>
                <Select
                  value={formData.engine}
                  onValueChange={(value: AIEngine) => setFormData({ ...formData, engine: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="deepseek">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        DeepSeek (Fast & Efficient)
                      </div>
                    </SelectItem>
                    <SelectItem value="gemini">
                      <div className="flex items-center gap-2">
                        <Brain className="h-4 w-4" />
                        Gemini (Versatile)
                      </div>
                    </SelectItem>
                    <SelectItem value="claude">
                      <div className="flex items-center gap-2">
                        <Brain className="h-4 w-4" />
                        Claude (Advanced Reasoning)
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="additional_knowledge">Additional Knowledge</Label>
                <Textarea
                  id="additional_knowledge"
                  placeholder="Add your own knowledge, expertise, or modifications to enhance the original persona..."
                  value={formData.additional_knowledge}
                  onChange={(e) => setFormData({ ...formData, additional_knowledge: e.target.value })}
                  rows={6}
                  className="font-mono text-sm"
                />
                <p className="text-sm text-muted-foreground mt-2">
                  This will be combined with the original knowledge base to create your enhanced version.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price_rental">Monthly Rental Price ($)</Label>
                  <Input
                    id="price_rental"
                    type="number"
                    placeholder="9.99"
                    value={formData.price_rental}
                    onChange={(e) => setFormData({ ...formData, price_rental: e.target.value })}
                    min="0"
                    step="0.01"
                  />
                </div>
                
                <div>
                  <Label htmlFor="price_purchase">One-time Purchase Price ($)</Label>
                  <Input
                    id="price_purchase"
                    type="number"
                    placeholder="49.99"
                    value={formData.price_purchase}
                    onChange={(e) => setFormData({ ...formData, price_purchase: e.target.value })}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <Button type="submit" disabled={isCreating} size="lg" className="w-full">
                {isCreating ? 'Creating Fork...' : 'Create Forked Persona'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Fork Process Visualization */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>How Forking Works</CardTitle>
          <CardDescription>
            Understanding the fork process
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center gap-4 text-sm">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                <Brain className="h-8 w-8 text-blue-600" />
              </div>
              <p className="font-medium">Original Persona</p>
              <p className="text-muted-foreground">Base knowledge</p>
            </div>
            
            <ArrowRight className="h-6 w-6 text-muted-foreground" />
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                <Plus className="h-8 w-8 text-green-600" />
              </div>
              <p className="font-medium">Your Additions</p>
              <p className="text-muted-foreground">Enhanced knowledge</p>
            </div>
            
            <ArrowRight className="h-6 w-6 text-muted-foreground" />
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-2">
                <GitFork className="h-8 w-8 text-purple-600" />
              </div>
              <p className="font-medium">Forked Persona</p>
              <p className="text-muted-foreground">Combined expertise</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

