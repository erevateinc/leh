// AI Engine Integration for LEH
// Using Puter.com free API endpoints as provided by CEO

export type AIEngine = 'deepseek' | 'gemini' | 'claude'

export interface AIMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface AIResponse {
  content: string
  engine: AIEngine
}

// DeepSeek API integration via Puter.com
export async function callDeepSeekAPI(messages: AIMessage[]): Promise<AIResponse> {
  try {
    const response = await fetch('https://api.puter.com/ai/deepseek', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: messages,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      throw new Error(`DeepSeek API error: ${response.status}`)
    }

    const data = await response.json()
    return {
      content: data.choices[0].message.content,
      engine: 'deepseek'
    }
  } catch (error) {
    console.error('DeepSeek API call failed:', error)
    throw error
  }
}

// Gemini API integration via Puter.com
export async function callGeminiAPI(messages: AIMessage[]): Promise<AIResponse> {
  try {
    const response = await fetch('https://api.puter.com/ai/gemini', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gemini-1.5-flash',
        messages: messages,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const data = await response.json()
    return {
      content: data.choices[0].message.content,
      engine: 'gemini'
    }
  } catch (error) {
    console.error('Gemini API call failed:', error)
    throw error
  }
}

// Claude API integration via Puter.com
export async function callClaudeAPI(messages: AIMessage[]): Promise<AIResponse> {
  try {
    const response = await fetch('https://api.puter.com/ai/claude', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        messages: messages,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      throw new Error(`Claude API error: ${response.status}`)
    }

    const data = await response.json()
    return {
      content: data.choices[0].message.content,
      engine: 'claude'
    }
  } catch (error) {
    console.error('Claude API call failed:', error)
    throw error
  }
}

// Main AI call function that routes to the appropriate engine
export async function callAI(
  engine: AIEngine,
  messages: AIMessage[]
): Promise<AIResponse> {
  switch (engine) {
    case 'deepseek':
      return callDeepSeekAPI(messages)
    case 'gemini':
      return callGeminiAPI(messages)
    case 'claude':
      return callClaudeAPI(messages)
    default:
      throw new Error(`Unsupported AI engine: ${engine}`)
  }
}

