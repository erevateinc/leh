// Payment utility functions for LEH

export interface PaymentData {
  personaId: string
  personaName: string
  priceType: 'rental' | 'purchase'
  amount: number
  currency?: string
}

export async function createPaymentSession(paymentData: PaymentData): Promise<{ sessionId: string; url: string }> {
  try {
    const response = await fetch('/api/payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(paymentData),
    })

    if (!response.ok) {
      throw new Error('Failed to create payment session')
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error('Payment session creation error:', error)
    throw error
  }
}

export function redirectToCheckout(url: string) {
  window.location.href = url
}

